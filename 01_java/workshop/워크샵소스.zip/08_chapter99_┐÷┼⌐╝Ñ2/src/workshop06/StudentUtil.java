package workshop06;

import java.util.Scanner;

public class StudentUtil {


	public static double round(double input){
		String data = String.format("%.2f", input);
		return Double.parseDouble(data);
	}
}
