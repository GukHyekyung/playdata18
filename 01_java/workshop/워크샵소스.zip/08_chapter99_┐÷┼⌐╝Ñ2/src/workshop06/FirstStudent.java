package workshop06;

public class FirstStudent extends Student {

	  private int absenceNum; //휴학년수
	  
	  public int getAbsenceNum() {
	  	return absenceNum;
	  }
	  public void setAbsenceNum(int absenceNum) {
	  	this.absenceNum = absenceNum;
	  }
	
	public FirstStudent(String stuId, String studName, int grade,
			int[] scoreArr, boolean scholarship , int absenceNum) {
		super(stuId, studName, grade, scoreArr, scholarship);
		this.absenceNum = absenceNum;
	}

	@Override
	public boolean isPassing() {
		// 1학년인 경우에는 평규이 80점이상 합격
		boolean result = false;
		if(getScoreAverage()>=80) result = true;
		
		return result;
	}

}

