package workshop06;

import java.util.Scanner;

public class GradeTest {

	public static void main(String[] args) {
		
		
		Scanner scan = new Scanner(System.in);
		
		GradeBiz biz = new GradeBiz();
		
		while (true) {
			printMenu();
			int inputMenu = scan.nextInt();
			
			if (inputMenu == 1) {
				biz.printStudent(GradeBiz.PRINT_ALL);
			} else if (inputMenu == 2) {
				biz.printStudent(GradeBiz.PRINT_PASS);
			} else if (inputMenu == 3) {
				biz.printStudent(GradeBiz.PRINT_FAIL);
			} else if (inputMenu == 4) {
				biz.printStudent(GradeBiz.PRINT_FIRST);
			} else if (inputMenu == 5) {
				biz.printStudent(GradeBiz.PRINT_FOURTH);
			}else if (inputMenu == 6) {
					biz.printStudent(GradeBiz.PRINT_JOB);
			} else if(inputMenu == 9){
				break;
			} else {
				System.out.println("메뉴를 잘못 입력하셨습니다.");
			}
		}
		System.out.println("학점 관리 시스템을 종료합니다.");

	}//end main

	

	private static void printMenu() {
		System.out.println("****<< 학점 관리 메뉴 >> ***");
		System.out.println("1. 전체학생 출력");
		System.out.println("2. 합격생 출력");
		System.out.println("3. 불합격생 출력");
		System.out.println("4. 1학년생 출력");
		System.out.println("5. 4학년생 출력");
		System.out.println("6. 취업자 출력");
		System.out.println("9. 종료");
		System.out.println("***********************");
		System.out.print("메뉴입력 => ");
	}

}//end class
