package workshop06;


public abstract class Student {
  private String stuId;  //학번
  private String studName;  //이름
  private int grade;  //  학년
  private int [] scoreArr;   //과목별 점수 배열
  private boolean scholarship; // 장학금 여부

public Student(String stuId, String studName, int grade, int[] scoreArr,
		boolean scholarship ) {
	super();
	this.stuId = stuId;
	this.studName = studName;
	this.grade = grade;
	this.scoreArr = scoreArr;
	this.scholarship = scholarship;

}

  
  public String getStuId() {
	return stuId;
}


public void setStuId(String stuId) {
	this.stuId = stuId;
}


public String getStudName() {
	return studName;
}


public void setStudName(String studName) {
	this.studName = studName;
}


public int getGrade() {
	return grade;
}


public void setGrade(int grade) {
	this.grade = grade;
}


public int[] getScoreArr() {
	return scoreArr;
}


public void setScoreArr(int[] scoreArr) {
	this.scoreArr = scoreArr;
}


public boolean getScholarship() {
	return scholarship;
}


public void setScholarship(boolean scholarship) {
	this.scholarship = scholarship;
}


public int getScoreTotal(){
	  int sum = 0;
	  for (int x : scoreArr) {
		  sum += x;
	   }
	  return sum;
  }
  
  public double getScoreAverage(){
	  double d = (double)(getScoreTotal())/scoreArr.length;
	  return StudentUtil.round(d);
  }
  
  //
  public abstract boolean isPassing();
  
@Override
public String toString() {
	return scoreArr[0]+"\t"+scoreArr[1]+"\t"+scoreArr[2]+"\t"+
				getScoreTotal()+"\t"+getScoreAverage();
}
  
  
}
