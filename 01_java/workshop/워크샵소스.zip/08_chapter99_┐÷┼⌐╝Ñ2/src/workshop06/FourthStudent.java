package workshop06;

public class FourthStudent extends Student {

	private boolean isJob; //취업여부
	
	public FourthStudent(String stuId, String studName, int grade,
			int[] scoreArr, boolean scholarship,  boolean isJob) {
		super(stuId, studName, grade, scoreArr, scholarship);
		this.isJob = isJob;
	}

	public boolean isJob() {
		return isJob;
	}

	public void setJob(boolean isJob) {
		this.isJob = isJob;
	}

	@Override
	public boolean isPassing() {
		// 4학년인 경우에는 평규이 70점이상 합격
		boolean result = false;
		if(getScoreAverage()>=70) result = true;
		
		return result;

	}

}
