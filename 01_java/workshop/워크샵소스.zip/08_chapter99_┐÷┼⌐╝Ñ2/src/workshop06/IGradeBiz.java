package workshop06;

public interface IGradeBiz {

	public static final int PRINT_ALL = 1;
	public static final int PRINT_PASS = 2;
	public static final int PRINT_FAIL = 3;
	public static final int PRINT_FIRST = 4;
	public static final int PRINT_FOURTH = 5;
	public static final int PRINT_JOB = 6;		
	public void printStudent(int printType);
}
