package workshop06;

public class GradeBiz implements IGradeBiz {

	private Student [] students = new Student[20];
	private int stuCount=0;
	

	public GradeBiz() {
		students[stuCount++] = new FirstStudent("A001", "유재석", 1, new int[]{70,66,78}, true, 0);
		students[stuCount++] = new FirstStudent("A002", "하하", 1, new int[]{90,100,95}, true, 2);
		students[stuCount++] = new FirstStudent("A003", "박명수", 1, new int[]{80,75,67}, true, 1);
		students[stuCount++] = new FourthStudent("B100", "이순신", 4, new int[]{70,86,75}, false, true);
		students[stuCount++] = new FourthStudent("B200", "유관순", 4, new int[]{69,70,70}, false, false);
		students[stuCount++] = new FourthStudent("B300", "강감찬", 4, new int[]{60,89,77}, true, false);
		students[stuCount++] = new FourthStudent("B400", "정도전", 4, new int[]{70,70,90}, false, false);
	}

	@Override
	public void printStudent(int printType) {
		
		    printTitle();
		    
		switch(printType){
		case PRINT_ALL: // 전체 학생 출력
			for(int i = 0 ;i < stuCount ; i++){
			    Student s = students[i];
			    StringBuffer buffer = new StringBuffer();
			  

			    buffer.append(s.getStuId());
			    buffer.append("\t");
			    buffer.append(s.getStudName());
			    buffer.append("\t");
			    buffer.append(s.getGrade());
			    buffer.append("\t");
			    buffer.append(s.toString());
			    buffer.append("\t");
			 	buffer.append((s.getScholarship()?"Y":"N"));
			 
			    buffer.append("\t");
				if(s instanceof FirstStudent){
					FirstStudent first = (FirstStudent)s;
					buffer.append((first.getScoreAverage()>=80 ? "합격":"불합격"));
					buffer.append("\t");
					buffer.append(first.getAbsenceNum());
					 buffer.append("\t");
				}else{
					 FourthStudent four = (FourthStudent)s;
					 buffer.append((four.getScoreAverage()>=70 ? "합격":"불합격"));
					 buffer.append("\t");
					 buffer.append("\t");
					 buffer.append((four.isJob()?"취업":"미취업"));
					 buffer.append("\t");
				}
			  System.out.println(buffer.toString());
			}//end for
			 break;
		case PRINT_PASS:  // 합격생만 출력
			for(int i = 0 ;i < stuCount ; i++){
				Student s = students[i];
				StringBuffer buffer = new StringBuffer();
				if( s.isPassing()){
			    buffer.append(s.getStuId());
			    buffer.append("\t");
			    buffer.append(s.getStudName());
			    buffer.append("\t");
			    buffer.append(s.getGrade());
			    buffer.append("\t");
			    buffer.append(s.toString());
			    buffer.append("\t");
			 	buffer.append((s.getScholarship()?"Y":"N"));
			    buffer.append("\t");
	
				if(s instanceof FirstStudent){
					FirstStudent first = (FirstStudent)s;
					buffer.append((first.getScoreAverage()>=80 ? "합격":"불합격"));
					buffer.append("\t");
					buffer.append(first.getAbsenceNum());
					 buffer.append("\t");

				}else{
					 FourthStudent four = (FourthStudent)s;
					 buffer.append((four.getScoreAverage()>=70 ? "합격":"불합격"));
					 buffer.append("\t");
					 buffer.append("\t");
					 buffer.append((four.isJob()?"취업":"미취업"));
					 buffer.append("\t");

				}
			  System.out.println(buffer.toString());
				}
			}//end for
			 break;
		case PRINT_FAIL:
			for(int i = 0 ;i < stuCount ; i++){
				Student s = students[i];
				StringBuffer buffer = new StringBuffer();
				if( ! s.isPassing()){
			    buffer.append(s.getStuId());
			    buffer.append("\t");
			    buffer.append(s.getStudName());
			    buffer.append("\t");
			    buffer.append(s.getGrade());
			    buffer.append("\t");
			    buffer.append(s.toString());
			    buffer.append("\t");
			 	buffer.append((s.getScholarship()?"Y":"N"));
			    buffer.append("\t");
	
				if(s instanceof FirstStudent){
					FirstStudent first = (FirstStudent)s;
					buffer.append((first.getScoreAverage()>=80 ? "합격":"불합격"));
					buffer.append("\t");
					buffer.append(first.getAbsenceNum());
					 buffer.append("\t");

				}else{
					 FourthStudent four = (FourthStudent)s;
					 buffer.append((four.getScoreAverage()>=70 ? "합격":"불합격"));
					 buffer.append("\t");
					 buffer.append("\t");
					 buffer.append((four.isJob()?"취업":"미취업"));
					 buffer.append("\t");

				}
			  System.out.println(buffer.toString());
				}
			}//end for
			 break;
		case PRINT_FIRST:
			for(int i = 0 ;i < stuCount ; i++){
				Student s = students[i];
				StringBuffer buffer = new StringBuffer();
				if( s.getGrade()==1){
			    buffer.append(s.getStuId());
			    buffer.append("\t");
			    buffer.append(s.getStudName());
			    buffer.append("\t");
			    buffer.append(s.getGrade());
			    buffer.append("\t");
			    buffer.append(s.toString());
			    buffer.append("\t");
			 	buffer.append((s.getScholarship()?"Y":"N"));
			    buffer.append("\t");
	
				if(s instanceof FirstStudent){
					FirstStudent first = (FirstStudent)s;
					buffer.append((first.getScoreAverage()>=80 ? "합격":"불합격"));
					buffer.append("\t");
					buffer.append(first.getAbsenceNum());
					 buffer.append("\t");

				}else{
					 FourthStudent four = (FourthStudent)s;
					 buffer.append((four.getScoreAverage()>=70 ? "합격":"불합격"));
					 buffer.append("\t");
					 buffer.append("\t");
					 buffer.append((four.isJob()?"취업":"미취업"));
					 buffer.append("\t");

				}
			  System.out.println(buffer.toString());
				}
			}//end for
			 break;
		case PRINT_FOURTH:
			for(int i = 0 ;i < stuCount ; i++){
				Student s = students[i];
				StringBuffer buffer = new StringBuffer();
				if( s.getGrade() == 4){
			    buffer.append(s.getStuId());
			    buffer.append("\t");
			    buffer.append(s.getStudName());
			    buffer.append("\t");
			    buffer.append(s.getGrade());
			    buffer.append("\t");
			    buffer.append(s.toString());
			    buffer.append("\t");
			 	buffer.append((s.getScholarship()?"Y":"N"));
			    buffer.append("\t");
	
				if(s instanceof FirstStudent){
					FirstStudent first = (FirstStudent)s;
					buffer.append((first.getScoreAverage()>=80 ? "합격":"불합격"));
					buffer.append("\t");
					buffer.append(first.getAbsenceNum());
					 buffer.append("\t");

				}else{
					 FourthStudent four = (FourthStudent)s;
					 buffer.append((four.getScoreAverage()>=70 ? "합격":"불합격"));
					 buffer.append("\t");
					 buffer.append("\t");
					 buffer.append((four.isJob()?"취업":"미취업"));
					 buffer.append("\t");

				}
			  System.out.println(buffer.toString());
				}
			}//end for
			 break;
		case PRINT_JOB:
			for(int i = 0 ;i < stuCount ; i++){
				Student s = students[i];
				StringBuffer buffer = new StringBuffer();
				if(s instanceof FourthStudent && ((FourthStudent)s).isJob()){
			    buffer.append(s.getStuId());
			    buffer.append("\t");
			    buffer.append(s.getStudName());
			    buffer.append("\t");
			    buffer.append(s.getGrade());
			    buffer.append("\t");
			    buffer.append(s.toString());
			    buffer.append("\t");
			 	buffer.append((s.getScholarship()?"Y":"N"));
			    buffer.append("\t");
	
		
					 FourthStudent four = (FourthStudent)s;
					 buffer.append((four.getScoreAverage()>=70 ? "합격":"불합격"));
					 buffer.append("\t");
					 buffer.append("\t");
					 buffer.append((four.isJob()?"취업":"미취업"));
					 buffer.append("\t");

				
			  System.out.println(buffer.toString());
				}
			}//end for
			 break;
		}//end switch
		System.out.println("===============================================================================================");
	}//end printStudent
	
	private  void printTitle() {
		System.out.println("===============================================================================================");
		System.out.println("학번\t이름\t학년\tHTML5\t자바\tC언어\t총점\t평균\t장학금\t합격여부\t휴학년수\t취업");
		System.out.println("===============================================================================================");
	}

}

