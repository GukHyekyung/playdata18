
public class ArrayTest04 {
	public static void main(String[] args) {
		
		int[] arr = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
		for(int i = 0; i < 10; i++) {
		System.out.print( arr[arr.length-1-i] + " ");
		}
	}

}
