import com.stu.Student;

public class TestStudent {

	public static void main(String[] args) {
		
		//배열로 관리
		Student [] stu = {new Student("홍길동", 15, 171, 81),
				          new Student("한사람", 13, 183, 72),
				          new Student("임걱정", 16, 175, 65)};
		
		
		// 1. 값 출력
		System.out.println("이름 \t 나이 \t 신장 \t 몸무게");
		for (Student s : stu) {
			System.out.println(s.getName()+"\t"+s.getAge()+"\t"
		 +s.getHeight()+"\t"+s.getWeight());
		}
		
		
		//2. 신장, 나이, 몸무게 평균 구하기
		double height_sum = 0;
		double age_sum = 0;
		double weight_sum = 0;
		
		for (Student s : stu) {
			height_sum += s.getHeight();
			age_sum += s.getAge();
			weight_sum += s.getWeight();
		}
		
		// * 콘솔(console)에 출력하는 3가지 방법
		
		// 1. System.out.println(값); 
//		System.out.println("나이의 평균:" + age_sum/stu.length);
//		System.out.println("신장의 평균:" + height_sum/stu.length);
//		System.out.println("몸무게의 평균:" + weight_sum/stu.length);
		
		//2. System.out.print(값)  ==> 개행없이 한 줄에 값을 출력하는 방식
//		System.out.print("홍길동");
//		System.out.print(20);
//		System.out.print("서울");
		
		//3. System.out.printf("출력할 포맷", 값, 값2, 값3);
		// %s: 문자열 맵핑
		// %d: 정수 맴핑
		// %f: 실수 맵핑
		// %c: 하나의 문자 맵핑
		// %b: true/false 맵핑
		
		
//		System.out.printf("이름:%s  나이:%d  성별:%c  키:%.2f  결혼여부:%b \n",
//				           "홍길동",    20,    '남',   182.365,  false);
////		System.out.println();
//		System.out.printf("이름:%s  나이:%d  성별:%c  키:%.2f  결혼여부:%b",
//		           "이순신",    40,    '남',   186.365,  true);
		
		
		System.out.printf("나이의 평균: %.2f \n", age_sum/stu.length);
		System.out.printf("신장의 평균: %.2f \n", height_sum/stu.length);
		System.out.printf("몸무게의 평균: %.2f \n", weight_sum/stu.length);
	}

}








